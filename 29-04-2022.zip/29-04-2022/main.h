void check_LSB(int num);
void check_MSB(int num);
void get_nth_bit(int num, int pos);
void set_nth_bit(int num, int pos);
void clear_nth_bit(int num, int pos);
void toggle_nth_bit(int num, int pos);
