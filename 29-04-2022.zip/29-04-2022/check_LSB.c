#include<stdio.h>
#include "main.h"

void check_LSB(int num)
{
	if(num & 1)
	{
		printf("LSB is set\n");
	}
	else
	{
		printf("LSB is not set\n");
	}
}
