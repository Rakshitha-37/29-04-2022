#include<stdio.h>
#include "main.h"

void set_nth_bit(int num, int pos)
{
	printf("Before set, num = %d\n", num);
	num = num | (1 << pos);
	printf("After set, num = %d\n", num);
}
