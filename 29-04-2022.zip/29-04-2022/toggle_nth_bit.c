#include<stdio.h>
#include "main.h"

void toggle_nth_bit(int num, int pos)
{
	printf("Before toggling, num = %d\n", num);
	num = num ^ (1 << pos);
	printf("After toggling, num = %d\n", num);
}
