#include<stdio.h>
#include "main.h"

void get_nth_bit(int num, int pos)
{
	if((num>>pos) & 1)
	{
		printf("%d bit is set\n", pos);
	}
	else
	{
		printf("%d bit is not set\n", pos);
	}
}
