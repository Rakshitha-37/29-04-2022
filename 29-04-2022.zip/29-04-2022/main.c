#include<stdio.h>
#include "main.h"

int main()
{
	int num, pos, option;
	printf("Enter number: ");
	scanf("%d", &num);
	printf("Enter position: ");
	scanf("%d", &pos);
	printf("1. check_LSB\n2. check_MSB\n3. get_nth_bit\n4. set_nth_bit\n5. clear_nth_bit\n6. toggle_nth_bit\nEnter option: ");
	scanf("%d", &option);
	switch(option)
	{
		case 1: check_LSB(num);
		        break;
		case 2: check_MSB(num);
			break;
		case 3: get_nth_bit(num, pos);
			break;
		case 4: set_nth_bit(num, pos);
			break;
		case 5: clear_nth_bit(num, pos);
			break;
		case 6: toggle_nth_bit(num, pos);
			break;
		default: printf("No action\n");
			 break;
	}
}
